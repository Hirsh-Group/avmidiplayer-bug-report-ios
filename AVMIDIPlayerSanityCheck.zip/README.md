
# AVMIDIPlayer Bug Report

This repo contains a simple example project that demonstrates the `AVMIDIPlayer` deadlocking when playing a simple multi-track MIDI file using two different soundfonts. Note the photo below is from the simulator to demo what the app looks like, but this app doesn't actually run in the simulator due to the `AVMIDIPlayer` only working on physical devices. 

<img src="https://res.cloudinary.com/drvibcm45/image/upload/v1610349752/Screen_Shot_2021-01-11_at_1.22.26_AM_vulcv9.png" width=400 />
